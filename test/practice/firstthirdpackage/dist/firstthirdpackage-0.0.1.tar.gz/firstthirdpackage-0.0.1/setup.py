from setuptools import setup

setup(name='firstthirdpackage', version='0.0.1', packages=['content'],
      author='under', author_email='under@126.com', license='Apache')
